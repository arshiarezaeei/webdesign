function toggleContent() {
    var content = document.getElementById('newPageContent');
    if (content.style.display === 'none') {
        content.style.display = 'block';
    } else {
        content.style.display = 'none';
    }
}
 
 let to=document.getElementById("inputto");
let from=document.getElementById("inputfrom");
let subject=document.getElementById("inputsubject");
let eria=document.getElementById("inputtext");

 function sentme() {
    let sent;
    
    sent.innerText=(to.value,from.value,subject.value,eris.value)
  

   
}




  