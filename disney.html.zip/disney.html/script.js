function greet() {
    document.getElementById('alltext').style="height:300px";
    document.getElementById('btnmore').style="display:none";
    document.getElementById('moretext').style="display:block";
}

function greet2() {
    document.getElementById('alltext2').style="height:300px";
    document.getElementById('btnmore2').style="display:none";
    document.getElementById('moretext2').style="display:block";
}

function greet3() {
    document.getElementById('alltext3').style="height:300px";
    document.getElementById('btnmore3').style="display:none";
    document.getElementById('moretext3').style="display:block";
}

function light() {
    
    document.getElementById("wholebody").style="background-color:#f2f2f2;color:black ;margin-right:30px"
    
    
}

function dark() {
   
    document.getElementById("wholebody").style="background-color:black; color:white; margin-right:30px "
    
}